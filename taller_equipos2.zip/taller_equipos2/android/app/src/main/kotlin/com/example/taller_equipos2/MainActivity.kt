package com.example.taller_equipos2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
