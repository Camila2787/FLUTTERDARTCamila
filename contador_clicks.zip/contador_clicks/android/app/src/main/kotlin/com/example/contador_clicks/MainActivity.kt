package com.example.contador_clicks

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
