package com.example.hoja_vida

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
