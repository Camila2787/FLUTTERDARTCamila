import 'package:flutter/material.dart';

class datosPersonalesScreen extends StatelessWidget {
  const datosPersonalesScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('DATOS PERSONALES'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildPersonalInfo(
              icon: Icons.person_4_rounded,
              title: 'Nombre:',
              content: 'María Camila Contreras Rangel',
            ),
            const SizedBox(height: 10),
            _buildPersonalInfo(
              icon: Icons.phone,
              title: 'Teléfono:',
              content: '3054014694',
            ),
            const SizedBox(height: 10),
            _buildPersonalInfo(
              icon: Icons.email,
              title: 'Correo:',
              content: 'camilacr2787@gmail.com',
            ),
            const SizedBox(height: 10),
            _buildPersonalInfo(
              icon: Icons.home,
              title: 'Dirección:',
              content: 'Calle 60-345',
            ),
            const SizedBox(height: 10),
            _buildPersonalInfo(
              icon: Icons.credit_card,
              title: 'Número de cédula:',
              content: '1000643706',
            ),
            const SizedBox(height: 10),
            _buildPersonalInfo(
              icon: Icons.cake,
              title: 'Fecha de nacimiento:',
              content: '01/16/2003',
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPersonalInfo({required IconData icon, required String title, required String content}) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, color: Colors.purple),
        const SizedBox(width: 10),
        Expanded(
          child: Text(
            '$title $content',
            textAlign: TextAlign.justify,
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
        ),
      ],
    );
  }
}

