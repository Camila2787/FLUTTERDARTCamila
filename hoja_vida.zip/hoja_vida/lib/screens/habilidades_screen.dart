import 'package:flutter/material.dart';

class habilidadesScreen extends StatelessWidget {
  const habilidadesScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Habilidades'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSkillItem(
              icon: Icons.heat_pump_rounded,
              title: 'Habilidades Técnicas',
              skills: [
                'Trabajo en equipo',
                'Empatía',
                'Trabajo bajo presión',
                'Excelente comunicación oral y escrita',
                'Conocimiento de la normativa laboral',
                'Proactividad',
              ],
            ),
            const SizedBox(height: 20),
            _buildSkillItem(
              icon: Icons.book,
              title: 'Habilidades Personales',
              skills: [
                'Amabilidad',
                'Entrega',
                'Sociabilidad',
                'Responsabilidad',
                'Trabajo en equipo',
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSkillItem({required IconData icon, required String title, required List<String> skills}) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, color: Colors.purple),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 5),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: skills
                    .map((skill) => Text(
                          '• $skill',
                          textAlign: TextAlign.justify,
                        ))
                    .toList(),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
