import 'package:flutter/material.dart';

class estudiosScreen extends StatelessWidget {
  const estudiosScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Estudios'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildEducationItem(
              icon: Icons.school_sharp,
              title: 'Bachiller: Colegio Calasanz Campestre Escolapias',
              subtitle: 'Tecnologías: Análisis y desarrollo de software\nDiplomado en física de la materia',
            ),
            const SizedBox(height: 20),
            _buildEducationItem(
              icon: Icons.person_off_rounded,
              title: 'Inglés: Nivel B1',
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEducationItem({required IconData icon, required String title, String subtitle = ''}) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, color: Colors.purple),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 5),
              Text(
                subtitle,
                textAlign: TextAlign.justify,
              ),
            ],
          ),
        ),
      ],
    );
  }
}
