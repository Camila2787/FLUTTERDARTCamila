import 'package:flutter/material.dart';
import 'package:hoja_vida/screens/datosPersonales_screen.dart';
import 'package:hoja_vida/screens/estudios_screen.dart';
import 'package:hoja_vida/screens/habilidades_screen.dart';

class MenuScreen extends StatelessWidget {
  const MenuScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Hoja de vida: María Camila Contreras Rangel'),
        backgroundColor: Colors.purple,
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: const [
            UserAccountsDrawerHeader(
              accountName: Text('María Camila Contreras Rangel'),
              accountEmail: Text('Estudiante'),
              currentAccountPicture: CircleAvatar(
                backgroundImage: NetworkImage('https://tse3.mm.bing.net/th?id=OIP.vidoUiMp8vHQY4EmHtIK-gHaEW&pid=Api&P=0&h=180'),
              ),
            ),
            // Otras opciones del drawer si es necesario
          ],
        ),
      ),
      body: ListView(
        children: [
          _buildListTile(
            title: 'Datos personales',
            icon: Icons.person,
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const datosPersonalesScreen()),
              );
            },
          ),
          _buildListTile(
            title: 'Estudio',
            icon: Icons.school,
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const estudiosScreen()),
              );
            },
          ),
          _buildListTile(
            title: 'Habilidades',
            icon: Icons.star_border_purple500,
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const habilidadesScreen()),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildListTile({required String title, String? subtitle, required IconData icon, required VoidCallback onTap}) {
    return ListTile(
      title: Text(title),
      subtitle: subtitle != null ? Text(subtitle) : null,
      leading: Icon(icon),
      trailing: const Icon(Icons.navigate_next_outlined),
      onTap: onTap,
    );
  }
}
